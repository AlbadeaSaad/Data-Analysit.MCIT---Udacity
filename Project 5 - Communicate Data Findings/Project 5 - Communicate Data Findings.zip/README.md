# (Bike Share Dataset Exploration)
## by Saad Salim Albadea


## Dataset

Bike Share is an application connected with multiple bike stations where people can rent a bike for a short or long trip. The idea of this application recevied a huge, positive impact from people because it solved two problems: 1- It made work, or school, drives more fun and with no gridlocks. 2- Driving with a bike is much more healthy. As a result, people arrive to work more excited. I am going to check duration, start and end time, starting point, ending point, bike id, user type, user age, and user gender to produce analytics to answer questions about the dataset


## Summary of Findings

>Only 17% of Bike Share users are the youngies. I imagined a percentage around 30%, but after uncovering more details about the dataset the numbers have started to make sense. 

>Customers have much longer average drive duration than subscribers. This need an in-field investegation to find a percise, detailed answer to.


>In day 17 (which is the day of highest average drive duration in the previous line plot.), the genders recorded their closest counts between each other.



## Key Insights for Presentation

- Generally, males are the highest number of users among females and Other.

- Adults are the highest users among youngies and old people.

- Although number of drives taken by subscribers are much more than customers, they have less average drive duration than customers.

- The 28th day of Fabuarary recorded the highest number of usage counts among all genders.

- Even though males are the highest in drive counts, Other genders have more drive duration average.